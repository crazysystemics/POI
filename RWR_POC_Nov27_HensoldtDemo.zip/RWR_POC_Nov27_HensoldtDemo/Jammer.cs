﻿using System.Collections.Generic;

public class Jammer : BattleSystem
{
    public override bool Stopped { get; set; }

    public override OutParameter Get()
    {
        return null;
    }
    public override void Set(List<InParameter> inParameters)
    {

    }
    public override void OnTick()
    {

    }
}