﻿public class OutParameter
{
    public int ID;
    public OutParameter(int id)
    {
        this.ID = id;
    }
}