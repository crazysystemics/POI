﻿public class InParameter
{
    public int ID;

    public InParameter(int ID)
    {
        this.ID = ID;
    }
}